# Full Review Rubric

Use this when creating `04_review_notes/01_full_review.md`.

## Required Checks

1. Field, level, and venue calibration
   - field/subfield
   - degree or manuscript level
   - target venue fit
   - recent target-venue anchors
   - alternative venue categories if needed

2. Title and abstract
   - always review first if present, even when the rest of the draft is early
   - use as a first-pass understanding check for intended problem, field, method, evidence, and contribution
   - title/abstract alignment
   - problem, gap, method, data, result, contribution
   - placeholder results or metrics
   - overclaim terms without evidence
   - separate title/abstract criticism from deeper method/result/contribution criticism

3. Problem significance
   - stated research problem
   - problem statement as a clear declarative statement, not a topic, question, deliverable, or preferred method
   - academic and practical value
   - too broad, too narrow, already solved, or weakly justified
   - problem survival: real condition, importance, unresolved context, simpler existing solutions, and whether the output would show problem reduction
   - prior attempts/evidence: what works, what does not, where, and what unresolved need remains
   - evidence needed to strengthen the problem

4. Literature review
   - synthesis vs paper-by-paper summary
   - problem/gap positioning
   - whether the author found a research problem from the literature rather than only choosing a topic or method
   - whether the author understands the research gap: known work, unresolved part, context/conditions, and why it matters
   - prior attempts: what works, what does not, where, for whom, and under what constraints
   - whether the gap is evidence-derived rather than asserted without support
   - uncited bibliography entries
   - missing citations for claims
   - decorative or inaccurate citations

5. Reference role clusters
   - direct prior work
   - method foundation
   - dataset/benchmark
   - evaluation/baseline
   - theory/framework
   - target-venue anchor
   - background or weak citation

6. Objective-problem alignment
   - every objective/RQ mapped to a problem/gap
   - objectives not derived from the problem
   - problems with no objective
   - activities mislabeled as research objectives
   - expected output that directly demonstrates problem resolution
   - claimed outcomes marked as measured, expected, or unsupported

7. Results and contribution
   - results reduce or solve the problem
   - results match objectives
   - evidence, metrics, validation, experiment, artifact, or analysis
   - implementation output vs research evidence
   - genuine failure: possible evidence that would make the answer "No", unfavorable conditions, and failure cases

8. Traceability
   - table: Problem/gap | Prior attempts/evidence | Unresolved need | Objective/RQ | Alternatives/selection rationale | Method | Data/evidence | Result | Output | Outcome/by-product | Claim supported? | Weak point
   - broken chains
   - unsupported claims
   - output/outcome confusion
   - by-products, side effects, cost, burden, and trade-offs that affect interpretation
   - stress-test status: problem survival, genuine failure, mandatory gates, measurement ceiling, no-new-problem

9. Method and alternatives
   - academic sense of the proposed solution
   - standard alternatives omitted
   - missing baselines
   - method justification
   - alternatives considered and selection rationale
   - novelty after strong baseline
   - mandatory gates before optimization: correctness, safety, security, ethics/legal, capacity, maximum error
   - no-new-problem guardrails: privacy, security, accessibility, cost, energy, maintainability, fairness, stakeholder burden

10. Data and feasibility
   - dataset/testbed availability
   - permission/privacy/labeling/ground truth risks
   - reproducibility path
   - narrowest defensible version
   - measurement ceiling: construct, operational indicator, instrument/ground truth, data procedure, analysis, and claim strength

11. Ethics, IRB, legal/regulatory
   - human subjects or identifiable data
   - IRB/ethics approval or exemption
   - consent and anonymization
   - scraping/platform ToS
   - dataset license, copyright, NDA, ownership
   - do not provide legal advice; flag what must be verified

12. Scope and limitations
   - scope as deliberate boundary
   - limitation as interpretive weakness
   - confusion between the two
   - missing limitations

13. LLM use and research responsibility
   - LLM use in writing, extraction, evaluation, generation, matching, or review
   - prompts, outputs, model name, date, setting, verification procedure
   - unverified LLM-derived claims

14. Acknowledgement
   - appropriate and specific
   - stable wording for long-lived thesis documents
   - obsolete affiliation/funding/support risk

15. Writing and document hygiene
   - typo frequency
   - abbreviation definition and consistency
   - Thai/English mixing
   - forward references
   - ambiguous pronouns and generic AI writing

16. Tables and figures
   - readability, labels, units, legends
   - caption quality
   - in-text references near the right location
   - evidence vs decoration

17. Verdict
   - readiness level
   - top blocking issues
   - high-impact fixes
   - minor issues
   - questions for author/advisor
   - next review pass
