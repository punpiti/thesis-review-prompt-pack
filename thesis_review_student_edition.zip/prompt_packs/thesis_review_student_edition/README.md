# Thesis Review Prompt Pack: Student Edition v1.5

Current version: `v1.5`

ชุด prompt นี้ทำไว้สำหรับให้นิสิตใช้ตรวจวิทยานิพนธ์ บทความจากวิทยานิพนธ์ หรือ manuscript ของตนเองและของเพื่อนอย่างเป็นระบบ ก่อนส่งให้อาจารย์หรือกรรมการตรวจรอบถัดไป

เป้าหมายคือฝึกให้นิสิตช่วยกันตรวจและให้ feedback ที่มีหลักฐาน ไม่ใช่ให้ AI ปรับปรุงงานแทนนิสิตโดยอัตโนมัติ ชุดนี้ช่วยให้เห็นว่าเอกสารมีปัญหาอะไรที่ควรแก้ก่อน เช่น ปัญหาวิจัยไม่ชัด วัตถุประสงค์ไม่ตรงกับผล literature review ยังไม่สังเคราะห์ reference ไม่พอ baseline ขาด หรือ claim แรงเกินหลักฐาน ไม่ใช่ให้ AI ตัดสินแทนผู้วิจัยหรือแทน reviewer จริง

รุ่นนี้เพิ่มแนวคิดจากบทเรียน AI-assisted thesis review ให้ตรวจ research logic ก่อน polish ภาษา โดยใช้ 5 stress tests: problem survival, genuine failure, mandatory gates, measurement ceiling และ no-new-problem guardrail พร้อมเพิ่มการไล่รอย Problem -> Prior attempts -> Unresolved need -> Objective/RQ -> Alternatives -> Method -> Evidence -> Output -> Outcome

ค่าเริ่มต้นของชุดนี้ตั้งใจให้เด็กใหม่ใช้ได้ก่อน: จัดไฟล์ สร้าง instruction แล้วสั่ง `ประเมิน` เพื่อให้เห็นปัญหาใหญ่และ action ที่ต้องทำ ไม่จำเป็นต้องใช้ prompt ขั้นสูงตั้งแต่รอบแรก

ถ้างานมีความก้าวหน้ามากขึ้นแล้ว เช่น มี draft หลักครบ มี reference/result พอสมควร และมี review notes รอบแรกแล้ว ค่อยใช้ `ประเมินเชิงลึก` เป็น advanced pass ระดับ reviewer/advisor หรือปริญญาเอก prompt นี้แยกไว้ที่ [06_deep_doctoral_review_prompt.md](06_deep_doctoral_review_prompt.md) เพื่อทดสอบ source triangulation, current consensus/debate, counter-argument, claim credibility, data interpretation และ decision brief โดยไม่ทำให้ prompt หลักยาวเกินไป

## Difficulty Levels

| Level | เหมาะกับใคร | ใช้คำสั่ง | ผลลัพธ์หลัก |
|---|---|---|---|
| Beginner | เด็กใหม่ ยังไม่รู้ว่าไฟล์ไหนสำคัญหรือ draft ขาดอะไร | `init workspace จากไฟล์รวม` แล้ว `เตรียม instruction จากงานปัจจุบัน` | file inventory, document map, missing inputs |
| Standard | draft เริ่มมีโครงครบ ต้องการ feedback ก่อนส่งอาจารย์ | `ประเมิน` | full review, reference audit, action checklist, review state |
| Advanced | draft มีหลักฐานมากขึ้น และต้องการทดสอบ argument ให้หนักขึ้น | `ประเมินเชิงลึก` | deep review, counter-arguments, claim audit, decisive tests |

สำหรับนิสิตทั่วไป ให้หยุดที่ `ประเมิน` ก่อน อ่าน review notes แล้วให้เจ้าของงานตัดสินใจแก้ blocking issues เองก่อนใช้ระดับ Advanced

## Student Reviewer Responsibility

ชุดนี้ใช้ AI เป็นผู้ช่วยอ่านและจัด feedback เท่านั้น นิสิตที่ตรวจงานต้องอ่าน review notes, ตรวจหลักฐาน, และอธิบายเหตุผลของ feedback เอง ส่วนเจ้าของงานต้องเป็นคนตัดสินใจปรับแก้ต้นฉบับเอง

หน้าที่ของ AI และเพื่อนผู้ตรวจคือชี้จุดอ่อน แนะนำแนวทาง และบอกหลักฐานที่ควรตรวจเพิ่ม จากนั้นเจ้าของงานต้องกลับไปคิดและทำเอง

อย่าใช้ workflow นี้เป็น auto-rewrite หรือ auto-improvement pipeline ถ้าจะให้ AI ช่วยแก้ข้อความ ต้องทำหลังจากมี review notes แล้วเท่านั้น และต้องทำบน working copy พร้อมตรวจ diff ก่อนรับการแก้ทุกครั้ง

ถ้านิสิตจะใช้ AI ต่อเพื่อช่วยพัฒนา argument, experiment, literature search, หรือ revision plan ให้นิสิตควรฝึกเขียน prompt เองจาก review notes แทนการให้ชุดนี้สั่ง AI ทำแทนทั้งหมด

## Companion Handout

แนะนำให้อ่านเอกสารประกอบการเรียน Research Methodology for AI-Assisted Thesis Review รุ่น public `2026.07` ก่อนเริ่มใช้ prompt pack นี้ โดยเฉพาะถ้าจะตรวจ thesis/manuscript ทั้งเล่ม:

- Public PDF/Markdown page: <https://punpiti.github.io/ai-assisted-thesis-review-handout/>
- Source copy ล่าสุดในเครื่องสอน: `C:\Users\punpi\OneDrive\Class\Research Methodology\01_Current_Teaching\AI-Assisted Thesis Review\public-github-pages\`
- เนื้อหาหลักที่ prompt pack รุ่นนี้นำมาใช้: Output/Outcome, prior attempts and unresolved need, alternatives and selection rationale, measurement ceiling, by-product, ethics/legal/responsible-AI checks และ five sharp thesis-review tests

ถ้าตรวจ thesis แบบจริงจัง ให้อ่าน handout ก่อนหรือให้ AI ใช้ handout เป็นกรอบประกอบการตั้งคำถามตรวจ แต่ยังต้องยึดหลักฐานจาก thesis/manuscript, references และ result files เป็นหลักเสมอ

## Quick Start

เปิดหน้าเริ่มต้นที่ [index.html](index.html) ก่อนเสมอ ชุดนี้แนะนำให้ใช้แบบ workspace เป็นหลัก:

- [index.html](index.html) - หน้าเริ่มต้นและตัวเลือก workflow
- [index-en.html](index-en.html) - English start page and workflow selection
- [workspace.html](workspace.html) - เส้นทางหลักสำหรับ Codex / Claude Code / Antigravity มีแนวทางติดตั้ง จัด workspace และสั่ง AI ตรวจไฟล์
- [workspace-en.html](workspace-en.html) - English workspace guide for Codex / Claude Code / Antigravity
- [webapp.html](webapp.html) - fallback สำหรับ Gemini / ChatGPT / Claude เฉพาะกรณีตรวจส่วนสั้น ๆ ไม่แนะนำสำหรับตรวจทั้งเล่ม
- [webapp-en.html](webapp-en.html) - English webapp fallback guide for short-section review
- [about.html](about.html) - รายละเอียดระบบ privacy ข้อจำกัด และรายการไฟล์
- [about-en.html](about-en.html) - English privacy, limits, and file list
- [VERSION.md](VERSION.md) - เลขเวอร์ชันและสรุปการเปลี่ยนแปลงของชุดนี้
- Companion handout 2026.07 - <https://punpiti.github.io/ai-assisted-thesis-review-handout/>

1. เปิด [index.html](index.html)
2. ใช้ [workspace.html](workspace.html) เป็นหลัก ถ้ามี Codex / Claude Code / Antigravity
3. ให้ AI ตรวจจากเอกสารก่อนว่าขาดอะไรและจำเป็นแค่ไหน ไม่ต้องกรอกข้อมูลซ้ำในเว็บ
4. ใช้ [webapp.html](webapp.html) เฉพาะกรณีไม่มี workspace AI และต้องตรวจข้อความสั้น ๆ

## Files

- [index.html](index.html) - หน้าเริ่มต้นแบบ HTML สำหรับ GitHub Pages หรือเปิดใน browser
- [index-en.html](index-en.html) - English start page
- [workspace.html](workspace.html) - คู่มือ HTML หลักสำหรับ Codex / Claude Code / Antigravity
- [workspace-en.html](workspace-en.html) - English workspace guide
- [webapp.html](webapp.html) - fallback สำหรับ Gemini / ChatGPT / Claude แบบ quota จำกัด
- [webapp-en.html](webapp-en.html) - English webapp fallback guide
- [about.html](about.html) - รายละเอียดระบบ privacy ข้อจำกัด และรายการไฟล์
- [about-en.html](about-en.html) - English privacy, limits, and file list
- [00_intake_checklist.md](00_intake_checklist.md) - checklist อ้างอิงแบบ Markdown สำหรับคนที่อยากเตรียม context เอง
- [01_full_thesis_review_prompt.md](01_full_thesis_review_prompt.md) - prompt หลักสำหรับตรวจทั้งเล่มหรือทั้ง manuscript
- [01_full_thesis_review_prompt_explained_th.html](01_full_thesis_review_prompt_explained_th.html) - หน้า HTML อธิบาย prompt หลักเป็นภาษาไทย สำหรับอ่านเพื่อเข้าใจแนวคิดก่อนใช้
- [01_full_thesis_review_prompt_explained_en.html](01_full_thesis_review_prompt_explained_en.html) - English HTML explanation of the main prompt concept
- [01_full_thesis_review_prompt_explained_en.md](01_full_thesis_review_prompt_explained_en.md) - English Markdown explanation of the main prompt concept
- [02_reference_bibtex_prompt.md](02_reference_bibtex_prompt.md) - prompt สำหรับตรวจ BibTeX, reference quality, citation use และ literature clusters
- [03_review_rubric.md](03_review_rubric.md) - rubric สำหรับ peer review และ self-review
- [04_common_review_patterns.md](04_common_review_patterns.md) - ข้อผิดพลาดที่พบบ่อยและวิธีตรวจ
- [05_choose_your_ai_workflow.md](05_choose_your_ai_workflow.md) - จุดเริ่มต้นสำหรับเลือก workflow ตามเครื่องมือที่มี
- [05a_chat_ai_quota_limited_guide.md](05a_chat_ai_quota_limited_guide.md) - วิธีใช้กับ Gemini / ChatGPT / Claude แบบ chat โดยเฉพาะกรณี quota จำกัด
- [05b_workspace_ai_codex_claude_code_guide.md](05b_workspace_ai_codex_claude_code_guide.md) - วิธีใช้กับ Codex / Claude Code / Antigravity หรือ AI ที่อ่านไฟล์ใน workspace ได้
- [06_deep_doctoral_review_prompt.md](06_deep_doctoral_review_prompt.md) - prompt เสริมสำหรับตรวจเชิงลึกระดับปริญญาเอกหลังจากมี review notes รอบแรก
- [AGENTS.md](AGENTS.md) - instruction สำหรับ workspace agents เมื่อนำ prompt pack ไปใช้กับ Codex / Claude Code / Antigravity
- [CLAUDE.md](CLAUDE.md) - instruction คู่กันสำหรับ Claude Code
- [workspace_template/](workspace_template/) - โครง workspace พร้อม `AGENTS.md`, `CLAUDE.md` และ README ในแต่ละโฟลเดอร์สำหรับให้นิสิตวางไฟล์งาน
- [codex_skill/SKILL.md](codex_skill/SKILL.md) - skill แบบย่อสำหรับ Codex หรือ agent ที่รองรับ skill เพื่อลดการ paste prompt ยาว
- [codex_research_workflow_router_skill/SKILL.md](codex_research_workflow_router_skill/SKILL.md) - router สำหรับเลือก skill ตามช่วงของ research lifecycle
- [codex_overview_review_skill/SKILL.md](codex_overview_review_skill/SKILL.md) - skill ภาพรวมสำหรับตัดสินว่างานถึงขั้นไหน และควรเรียก skill ย่อยใด
- [codex_title_abstract_outcome_skill/SKILL.md](codex_title_abstract_outcome_skill/SKILL.md) - skill สำหรับ title, abstract, expected output/outcome และ contribution snapshot
- [codex_proposal_readiness_skill/SKILL.md](codex_proposal_readiness_skill/SKILL.md) - skill สำหรับตรวจโครงร่างวิจัยระยะต้น โดยดู title direction, introduction funnel, problem framing, RQ/objective/methodology fit และ expected contribution
- [codex_research_question_hypothesis_skill/SKILL.md](codex_research_question_hypothesis_skill/SKILL.md) - skill สำหรับ refine RQ/hypothesis, variables, conceptual model และ testability
- [codex_introduction_review_skill/SKILL.md](codex_introduction_review_skill/SKILL.md) - skill สำหรับ introduction, problem statement, objective/RQ และ scope
- [codex_literature_review_skill/SKILL.md](codex_literature_review_skill/SKILL.md) - skill สำหรับ literature review, research problem discovery และ research gap understanding
- [codex_systematic_review_protocol_skill/SKILL.md](codex_systematic_review_protocol_skill/SKILL.md) - skill สำหรับ systematic/scoping review protocol, search strategy, screening/extraction และ synthesis plan
- [codex_experiment_design_skill/SKILL.md](codex_experiment_design_skill/SKILL.md) - skill สำหรับ experiment/evaluation design, baseline, metric และ genuine failure
- [codex_data_analysis_interpretation_skill/SKILL.md](codex_data_analysis_interpretation_skill/SKILL.md) - skill สำหรับ statistical analysis plan, result interpretation, visualization และ robustness checks
- [codex_manuscript_revision_submission_skill/SKILL.md](codex_manuscript_revision_submission_skill/SKILL.md) - skill สำหรับ manuscript self-review, submission package และ reviewer response
- [codex_collaboration_productivity_skill/SKILL.md](codex_collaboration_productivity_skill/SKILL.md) - skill สำหรับ advisor meeting, collaboration communication, agenda และ action tracking
- [codex_latex_document_production_skill/SKILL.md](codex_latex_document_production_skill/SKILL.md) - skill สำหรับติดตั้ง/ตรวจ LaTeX, เลือก venue template, ตั้งค่า TH Sarabun New/ฟอนต์, แก้กล่องสี่เหลี่ยม, ตาราง autofit และ final PDF QA
- [codex_venue_status_prognosis_skill/SKILL.md](codex_venue_status_prognosis_skill/SKILL.md) - skill สำหรับเลือก venue/category, วิจารณ์สถานะ readiness และพยากรณ์ความเป็นไปได้เชิงคุณภาพตอนจบ
- [codex_reference_bibtex_skill/SKILL.md](codex_reference_bibtex_skill/SKILL.md) - skill แยกสำหรับตรวจ ref, สร้าง BibTeX, วิเคราะห์ reference set จาก BibTeX และตรวจ citation use
- [STUDENT_HANDOUT.md](STUDENT_HANDOUT.md) - ข้อความสั้นสำหรับส่งให้นิสิตในแชต อีเมล หรือ LMS
- [LICENSE.md](LICENSE.md) - เงื่อนไขการนำไปใช้และเผยแพร่ต่อ
- [VERSION.md](VERSION.md) - เลขเวอร์ชันและสรุปการเปลี่ยนแปลง

## What You Must Prepare

ถ้าไม่อยากสร้างโฟลเดอร์เอง ให้เริ่มจาก `workspace_template/` แล้วคัดลอกเป็น workspace ของงานนั้น

ให้รัน install command ใน [workspace.html](workspace.html) จากโฟลเดอร์ที่ต้องการสร้างงาน command จะดาวน์โหลด zip และสร้าง project folder จาก `workspace_template/`

ค่าเริ่มต้นคือ `my_thesis_review/` ถ้าต้องการชื่ออื่น ให้แก้ตัวแปร `PROJECT` หรือ `$Project` ใน command ก่อนรัน

Linux / macOS:

```bash
wget -O install-thesis-review.sh https://punpiti.github.io/thesis-review-prompt-pack/install-thesis-review.sh
bash install-thesis-review.sh my_thesis_review
```

Windows PowerShell:

```powershell
Invoke-WebRequest -Uri "https://punpiti.github.io/thesis-review-prompt-pack/install-thesis-review.ps1" -OutFile ".\install-thesis-review.ps1"
PowerShell -ExecutionPolicy Bypass -File ".\install-thesis-review.ps1" -Project "my_thesis_review"
```

installer ทำแค่ดาวน์โหลดชุด prompt, แตก zip, และสร้าง workspace จาก template เท่านั้น หลังจากนั้นนิสิตยังต้องวางไฟล์เอง อ่าน review notes เอง และคิด prompt ต่อเองจากปัญหาที่พบ การดาวน์โหลดและแตก ZIP จะทำใน temporary directory จึงไม่ทับไฟล์ `thesis_review_student_edition.zip` หรือโฟลเดอร์ `prompt_packs/` ที่ผู้ใช้อาจมีอยู่แล้วในโฟลเดอร์ที่รัน installer

ในการติดตั้งครั้งแรก ถ้าชื่อ project ชนกับไฟล์ธรรมดาที่มีอยู่ installer จะหยุดและแจ้งข้อผิดพลาด ถ้าชนกับโฟลเดอร์เดิม จะถือว่าเป็น existing workspace และใช้ safe update โดยไม่ทับไฟล์เดิม

ถ้ารัน installer ทับ workspace เดิม รุ่นใหม่จะใช้ safe update เป็นค่าเริ่มต้น:

- เช็ค `VERSION.md` ล่าสุดจาก GitHub Pages ที่ <https://punpiti.github.io/thesis-review-prompt-pack/VERSION.md>
- ไม่ทับไฟล์ workspace template ที่มีอยู่แล้ว
- backup `prompt_pack/` เดิมเป็น `prompt_pack_backup_<timestamp>`
- ติดตั้ง prompt pack รุ่นใหม่ใน `prompt_pack/`
- บันทึก local/remote/installed version ลง `PROMPT_PACK_VERSION.md`
- สร้าง `PROMPT_PACK_UPDATE_NOTES_<timestamp>.md` เพื่อให้ AI/ผู้ใช้เทียบแนวคิดใหม่ก่อนรับเข้า workspace
- ไม่ควรทับ thesis source, review notes หรือ instruction ที่มีงานค้าง

ถ้าต้องการ refresh template files จริง ๆ ให้ตั้ง `THESIS_REVIEW_INSTALL_MODE=overwrite` แต่ควรทำเฉพาะเมื่อ backup แล้ว

ตัวอย่างคำสั่งสำหรับอัปเดต workspace เดิมแบบ safe update:

Linux / macOS:

```bash
wget -O install-thesis-review.sh https://punpiti.github.io/thesis-review-prompt-pack/install-thesis-review.sh
bash install-thesis-review.sh my_thesis_review
```

Windows PowerShell:

```powershell
Invoke-WebRequest -Uri "https://punpiti.github.io/thesis-review-prompt-pack/install-thesis-review.ps1" -OutFile ".\install-thesis-review.ps1"
PowerShell -ExecutionPolicy Bypass -File ".\install-thesis-review.ps1" -Project "my_thesis_review"
```

กรณีตั้งใจ refresh template files หลัง backup แล้ว:

```bash
wget -O install-thesis-review.sh https://punpiti.github.io/thesis-review-prompt-pack/install-thesis-review.sh
THESIS_REVIEW_INSTALL_MODE=overwrite bash install-thesis-review.sh my_thesis_review
```

```powershell
Invoke-WebRequest -Uri "https://punpiti.github.io/thesis-review-prompt-pack/install-thesis-review.ps1" -OutFile ".\install-thesis-review.ps1"
PowerShell -ExecutionPolicy Bypass -File ".\install-thesis-review.ps1" -Project "my_thesis_review" -Mode "overwrite"
```

หลังอัปเดต workspace เดิม ให้เปิดใน Codex / Claude Code แล้วสั่ง:

```text
เช็คเวอร์ชัน prompt_pack กับ GitHub Pages และสรุปแนวคิดใหม่ที่ควรรับเข้ามา โดยห้ามทับ review notes, instruction เดิม, หรือสิ่งที่ user เคยใช้แล้ว
```

หลักการคือรับ “แนวคิดใหม่” จาก prompt pack รุ่นล่าสุดเป็นข้อเสนอ patch เท่านั้น เช่น gate ใหม่, skill ใหม่, หรือข้อควรระวังใหม่ ไม่ใช่การแทนที่ `AGENTS.md`, `CLAUDE.md`, `00_review_instructions/`, หรือ workflow ที่ workspace นั้นใช้งานไปแล้วแบบอัตโนมัติ

จากนั้นให้ใส่ไฟล์รวมทั้งหมดใน `my_thesis_review/00_inbox/` แล้วสั่ง `init workspace จากไฟล์รวม`

ใส่ได้ทั้ง thesis/manuscript, LaTeX, Word, PDF, BibTeX, reference PDF, รูป, ตาราง, ผลทดลอง, script, log, metric และ baseline

`00_review_instructions/` และ `02_references/extracted_md/` ให้ AI สร้างเอง

## Why This Saves Tokens

อย่าให้ AI อ่านทั้งโฟลเดอร์ LaTeX หรือไฟล์ทั้งหมดแบบเหมารวมตั้งแต่แรก เพราะจะใช้ token มากและอาจทำให้ AI อ่านไฟล์ที่ไม่เกี่ยวกับการตรวจ

workflow นี้ให้ AI เริ่มจาก `00_inbox/` เพื่อจัดไฟล์และสร้าง `00_review_instructions/` ก่อน จากนั้นตอนสั่ง `ประเมิน` ให้ใช้ context ที่คัดแล้วเป็นหลัก แทนการอ่านทุกไฟล์ซ้ำทุกรอบ

## Ground Rules

- AI ช่วยอ่านและจัดระบบ feedback ได้ แต่ผู้ตรวจและผู้เขียนต้องรับผิดชอบเหตุผลของ feedback และ claim ทุกข้อเอง
- ชุดนี้ไม่ใช่ระบบปรับปรุงต้นฉบับอัตโนมัติ ให้สร้าง review notes ก่อนเสมอ แล้วให้เจ้าของงานตัดสินใจแก้เอง
- เป้าหมายคือชี้จุดอ่อน แนะนำ และให้เจ้าของงานไปทำเอง ไม่ใช่ให้ AI ทำ revision ให้ครบแทน
- ถ้าต้องใช้ AI ต่อ นิสิตควรฝึกตั้ง prompt จากปัญหาที่พบเอง เช่น ขอ checklist, ขอคำถามตรวจ source, หรือขอทางเลือก experiment ไม่ใช่สั่งให้ rewrite ทั้งงาน
- ห้ามให้ AI แต่ง citation, DOI, venue metric, paper title, result หรือ ranking เอง
- ถ้าไม่แน่ใจ ให้เขียนว่า `ยังไม่ได้ตรวจสอบ` แทนการเดา
- citation ทุกตัวควรตรวจจาก paper หรือหน้าเว็บ/ข้อมูลจากแหล่งทางการ
- cited key ทุกตัวใน manuscript ต้องมีอยู่จริงใน BibTeX/reference list
- BibTeX/reference-list entry ทุกตัวควรถูก cite หรือถูก mark ชัดว่า unused/background
- scholarly reference ทุกรายการควรมี PDF ต้นฉบับใน `02_references/pdf/`; ถ้าไม่มี PDF ให้บันทึกเป็น missing input และระบุ official page/DOI/publisher page ที่ใช้เป็น fallback
- BibTeX ที่ถือว่าพร้อมควรมี author, title, year, venue, DOI หรือ URL, pages/article number เมื่อมี, publisher เมื่อเกี่ยวข้อง, entry type ที่ถูกต้อง, และ abstract เมื่อมีหลักฐานจาก PDF หรือ official source
- ถ้าใช้ Codex หรือ Claude Code อ่าน PDF reference ให้ AI เก็บบันทึกผลอ่านเป็น Markdown ใน `02_references/extracted_md/` หนึ่งไฟล์ต่อหนึ่ง PDF ก่อนนำไปเติม `abstract` หรือ metadata ใน BibTeX
- claim เชิงผลทดลองต้องมี dataset, baseline, metric, raw result และวิธีคำนวณรองรับ
- ถ้ามี title หรือ abstract ให้ตรวจก่อนเสมอเพื่อจับแกนงาน แต่ให้แยกคำวิจารณ์ title/abstract ออกจากการตัดสิน method/result/contribution ที่อาจยังไม่พร้อมในงานระยะต้น
- งาน proposal ระยะต้นให้ตรวจเป็น readiness ไม่ใช่รีบเขียนแทน: ดู title direction, introduction funnel จากบริบทกว้างสู่บริบทเฉพาะ, problem framing ที่แยก ideal/reality/consequence/gap, RQ-objective-methodology alignment และ contribution แยก academic/practical
- literature review ต้องตรวจว่าเขาหา research problem เจอจาก prior work หรือไม่ และเข้าใจ research gap แค่ไหน ไม่ใช่แค่สรุป paper หรือรวบ citation
- ก่อนแก้ภาษา ให้ตรวจว่า problem ยังรอด, งานมีโอกาส fail ได้จริง, mandatory gates ผ่านก่อน optimization, metric วัด construct ที่ claim จริง และ solution ไม่สร้างปัญหาใหม่ที่ยอมรับไม่ได้
- แยก `output` ออกจาก `outcome`: output คือหลักฐานตรงว่าปัญหาถูกแก้ตาม objective; outcome คือสิ่งที่เกิดตามมาหลังปัญหาถูกแก้ และห้าม claim ว่าเกิดขึ้นจริงถ้าไม่ได้วัด
- contribution ควรไล่รอยกลับไปได้ถึง prior attempts, unresolved need, alternatives/selection rationale, method, evidence, output, outcome/by-product และ limitation
- ใช้ L1-L4 ในการแยกสถานะ review: L1 คือสิ่งที่ AI ตรวจจากไฟล์ได้, L2 คือ judgment ของนิสิต/อาจารย์/กรรมการ, L3 คือ feedback หรือข้อมูลภายนอกที่ยังต้องเก็บ/verify, และ L4 คือหลักฐานไฟล์จริงใน workspace เช่น manuscript, BibTeX, PDFs, official pages, results, scripts/logs
- ระบุปัญหาตามระดับหัวข้อที่เล็กที่สุดที่หลักฐานรองรับ: `document -> chapter/section -> subsection/paragraph -> claim/evidence -> citation/BibTeX/PDF`
- งาน reference/BibTeX ควรเป็น skill แยกได้เอง: `ตรวจ ref`, `สร้าง BibTeX`, `วิเคราะห์ ref จาก BibTeX`, และ `ตรวจ citation use` ไม่จำเป็นต้องรัน full thesis review ก่อน
- หัวข้อหลักควรเป็น skill แยก: title/abstract/expected outcome, introduction, literature review, experiment design, reference/BibTeX และมี overview skill อีกตัวเพื่อดูภาพรวมและเลือกตรวจเฉพาะส่วนที่พร้อม
- ถ้าโจทย์กว้างหรือไม่รู้ควรใช้ skill ไหน ให้ใช้ research workflow router ก่อน เพื่อเลือกเฉพาะ skill ที่เหมาะกับช่วงงาน เช่น RQ/hypothesis, SLR protocol, data interpretation, manuscript revision, collaboration หรือ venue/status
- งาน LaTeX/PDF production ควรเป็น skill แยกจากการประเมินเนื้อหา: ตรวจ engine/package/template ตาม venue, Thai font/TH Sarabun New, กล่องสี่เหลี่ยมในภาษาอังกฤษหรือสัญลักษณ์คณิตศาสตร์, table/column autofit, hanging heading และ hanging line ก่อนเรียก PDF ว่า final
- การเลือก venue/category และการสรุปสถานะหรือพยากรณ์ความเป็นไปได้เชิงคุณภาพตอนจบควรเป็น skill แยก และต้องอิง evidence ที่ตรวจแล้ว ไม่ใช่เดา acceptance หรือ venue ranking
- งานยังไม่ถึงหัวข้อไหนไม่ต้องรีบตรวจหัวข้อนั้น ให้ mark ว่า `not ready for this skill` และบอก minimum missing inputs
- ถ้างานเกี่ยวข้องกับคน ผู้ใช้ ข้อมูลส่วนบุคคล scraping dataset license หรือข้อมูลที่มีข้อบังคับ ต้องตรวจ IRB/ethics/legal compliance ตั้งแต่ต้น
- ถ้างานใช้ LLM ต้องบอกให้ชัดว่าใช้ทำอะไร และตรวจผลจากแหล่งจริงอย่างไร
- ตรวจคุณภาพการเขียนด้วย เช่น ใช้ AI แบบ generic หรือไม่ สะกดผิดมากเกินเหตุหรือไม่ ใช้ชื่อย่อเหมาะสมหรือไม่ ปนไทย/อังกฤษเกินจำเป็นหรือไม่ และลำดับการอธิบายทำให้ผู้อ่านต้องไปรู้สิ่งที่อยู่ด้านหลังก่อนหรือไม่

## Suggested Workflow

แนะนำให้ใช้แบบ workspace เป็นหลัก เพราะการตรวจวิทยานิพนธ์ต้องอ่านหลายไฟล์ ถามกลับหลายรอบ และต้องสร้าง review notes ที่อ้างตำแหน่งในเอกสารได้ ถ้าใช้ AI webapp ให้ใช้เฉพาะตรวจข้อความสั้น ๆ ไม่ใช่ตรวจทั้งเล่ม

### Round 1: Readiness Check

ถ้าเริ่มจากไฟล์รวมใน `00_inbox/` ให้สั่ง:

```text
init workspace จากไฟล์รวม
```

จากนั้นให้ AI สำรวจ workspace แล้วสร้างหรืออัปเดต `00_review_instructions/review_profile.md`, `00_review_instructions/document_map.md`, `00_review_instructions/review_scope.md` และ `00_review_instructions/missing_inputs.md`

ถ้างานเป็น LaTeX ให้ AI อ่าน root `.tex`, ตาม `\input{}` และ `\include{}` เท่าที่จำเป็น แล้วจัด context ลง instruction folder ก่อน ไม่ต้องให้นิสิตกรอกเอง

### Round 2: Full Review ด้วยคำสั่งสั้น

ถ้าใช้ workspace AI ให้สั่งสั้น ๆ ว่า:

```text
ประเมิน
```

AI ควรตรวจความสอดคล้องของทั้งงานตาม [01_full_thesis_review_prompt.md](01_full_thesis_review_prompt.md), ตรวจ references ตาม [02_reference_bibtex_prompt.md](02_reference_bibtex_prompt.md), และสร้าง review notes ให้ครบเท่าที่หลักฐานมี โดยห้ามแก้ thesis ต้นฉบับทันที

ดู template โครงรายงานได้ที่ [templates/04_review_notes/01_full_review_TEMPLATE.md](templates/04_review_notes/01_full_review_TEMPLATE.md)

ถ้าต้องการเข้าใจว่าทำไม prompt ตรวจหัวข้อเหล่านี้ ให้อ่าน [01_full_thesis_review_prompt_explained_th.html](01_full_thesis_review_prompt_explained_th.html) หรือ English version ที่ [01_full_thesis_review_prompt_explained_en.html](01_full_thesis_review_prompt_explained_en.html)

### Round 3: State Note สำหรับกลับมาทำต่อ

ให้ AI สร้างหรืออัปเดต `04_review_notes/99_review_state.md` ทุกครั้ง เพื่อบอกว่าเคยประเมินอะไรเสร็จแล้ว อะไรค้างเพราะขาดหลักฐาน และคราวหน้าควรใช้ prompt อะไรทำต่อ

ดู template ได้ที่ [templates/04_review_notes/99_review_state_TEMPLATE.md](templates/04_review_notes/99_review_state_TEMPLATE.md)

ถ้ากลับมารอบหน้า ให้สั่ง:

```text
ประเมินต่อจาก 04_review_notes/99_review_state.md
```

AI ควรประเมินเฉพาะหัวข้อที่เหลือ ยกเว้นผู้ใช้สั่งชัดว่า `ประเมินใหม่ทั้งหมด`

### Round 4: Deep Doctoral Review

ใช้เป็นขั้นสูงเท่านั้น เมื่อมีผลตรวจรอบแรกแล้วและงานมีเนื้อหาพอให้โจมตี argument ได้ เช่น ก่อน proposal defense, defense, manuscript submission หรือ revision ใหญ่:

```text
ประเมินเชิงลึก
```

AI ควรใช้ [06_deep_doctoral_review_prompt.md](06_deep_doctoral_review_prompt.md), สร้าง `04_review_notes/04_deep_review.md`, เพิ่ม action ที่พบใหม่ใน `04_review_notes/03_student_action_checklist.md` และอัปเดต `04_review_notes/99_review_state.md`

ถ้า draft ยังต้นมาก หรือยังไม่มี reference/result พอ ให้ยังไม่ต้องใช้ `ประเมินเชิงลึก` เพราะจะได้รายการ missing input มากกว่าคำแนะนำที่แก้ได้ทันที

### Round 5: Fix and Recheck

ให้ AI สรุป `04_review_notes/03_student_action_checklist.md` เพื่อเป็น feedback จากการตรวจ แล้วผู้เขียนเป็นคนตัดสินใจแก้ blocking issues เองก่อนแก้ภาษา เช่น problem ไม่ชัด objective ไม่ตรง result ไม่มี baseline หรือ citation รองรับ claim ไม่ได้

หมายเหตุ: `04_review_notes/03_student_action_checklist.md` เป็นไฟล์ที่ AI ต้องสร้างใน workspace ของนิสิต ไม่ใช่ไฟล์ที่มีมาให้ตั้งแต่แรก ดูตัวอย่างรูปแบบได้ที่ [templates/04_review_notes/03_student_action_checklist_TEMPLATE.md](templates/04_review_notes/03_student_action_checklist_TEMPLATE.md)
