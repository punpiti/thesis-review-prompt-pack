# ANTIGRAVITY.md

<!-- BEGIN AGENT-PROJECT-KIT-ADAPTER -->
This project uses Agent Project Kit.

Read these first:

1. `AGENTS.md`
2. `.ai/PROJECT_STATE.md`
3. `.ai/PROJECT_HIERARCHY.md`
4. `.ai/COMPUTING_ENVIRONMENT_VERSION.md`
5. `.ai/MACHINE_PROFILE.md`
6. `.ai/LOCAL_RESOURCES.md`
7. `.ai/MACHINE_COMPATIBILITY.md`
8. `.ai/RUNBOOK.md`
9. `.ai/TOKEN_BUDGET.md`

Follow the Spec-Eval-Loop workflow in `AGENTS.md`.
Do not overwrite project-local `.ai/` state when updating Agent Project Kit.
<!-- END AGENT-PROJECT-KIT-ADAPTER -->
