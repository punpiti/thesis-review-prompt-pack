# 03 Thesis Review Rubric

ใช้ rubric นี้ประกอบผลจาก AI และการอ่านของผู้ตรวจ ไม่ควรใช้คะแนนแทนคำอธิบายเชิงหลักฐาน

คะแนนแนะนำ: 0 = ไม่มี / 1 = อ่อนมาก / 2 = ยังไม่พอ / 3 = พอใช้สำหรับ draft / 4 = แข็ง / 5 = พร้อมระดับ venue ที่ตั้งเป้า

| Dimension | What to Check | Score |
|---|---|---:|
| Field and venue fit | สาขา ระดับ thesis และ target venue ชัดและสมเหตุสมผล | 0-5 |
| Venue/status prognosis discipline | การเลือก venue/category และ readiness verdict อิงหลักฐานที่ตรวจแล้ว แยก qualitative prognosis จากการเดา acceptance/ranking และระบุ live verification ที่ต้องทำ | 0-5 |
| L1-L4 review discipline | แยกชัดว่า AI ตรวจอะไรได้เอง อะไรต้องใช้ judgment มนุษย์ อะไรต้องรอ external feedback/live verification และหลักฐานไฟล์ใดมี/ไม่มีใน workspace | 0-5 |
| Topic hierarchy discipline | ระบุปัญหาได้ถึงระดับ document/chapter/section/paragraph/claim/citation เท่าที่หลักฐานรองรับ ไม่วิจารณ์กว้างเกินตำแหน่งจริง | 0-5 |
| Title-abstract first-pass clarity | ถ้ามี title/abstract ต้องตรวจเป็นด่านแรกเพื่อเข้าใจแกนงาน และแยกคำวิจารณ์ส่วนนี้ออกจาก method/result ที่อาจยังไม่พร้อมใน draft ต้นทาง | 0-5 |
| Title-abstract alignment | title และ abstract สื่อเรื่องเดียวกัน และ title เหมาะกับ contribution | 0-5 |
| Problem significance | ปัญหามีน้ำหนัก มี gap มีคุณค่าทางวิชาการหรือปฏิบัติ | 0-5 |
| Problem statement discipline | ข้อความระบุปัญหาเป็นประโยคบอกเล่าชัด มีสภาพไม่พึงประสงค์หรือยังไม่คลี่คลายหนึ่งเรื่อง ไม่ใช่หัวข้อ คำถาม หรือวิธีที่ชอบ | 0-5 |
| Problem framing completeness | แยกสภาพที่ควรเป็น สภาพจริง ผลกระทบหากไม่แก้ และ research gap ได้ชัด ไม่ใช่บ่นปัญหาลอย ๆ | 0-5 |
| Prior attempts and unresolved need | แสดงว่าใครเคยทำอะไร อะไรใช้ได้/ใช้ไม่ได้ ภายใต้เงื่อนไขใด และยังเหลือความจำเป็นของงานนี้ตรงไหน | 0-5 |
| Literature synthesis | literature review สังเคราะห์งาน ไม่ใช่แค่สรุปทีละ paper | 0-5 |
| Literature-to-problem discovery | literature review ทำให้เห็นว่า author หา research problem เจอจาก prior work ไม่ใช่แค่เลือก topic/method | 0-5 |
| Research gap understanding | author เข้าใจ gap ว่าอะไร known แล้ว อะไรยัง unresolved อยู่ในบริบท/เงื่อนไขใด และทำไม gap นั้นสำคัญ | 0-5 |
| Reference quality | reference สำคัญ ครบ เชื่อถือได้ และเหมาะกับ reviewer ในสาขา | 0-5 |
| Citation integrity | ไม่มี reference ที่ไม่ถูก cite ไม่มี claim สำคัญที่ไร้ cite และ cite ตรงประเด็น | 0-5 |
| Reference existence gate | cited key ทุกตัวมีอยู่จริงใน BibTeX/reference list และไม่มี BibTeX entry ที่ดูแต่งขึ้นหรือ trace ไม่ได้จากหลักฐานที่ให้มา | 0-5 |
| Reference source coverage | scholarly reference แต่ละรายการมี PDF ในมือหรือ official source fallback ที่ระบุชัด พร้อมรายการ missing PDFs | 0-5 |
| BibTeX completeness | BibTeX มี field สำคัญครบตามประเภท entry และ metadata/abstract trace ได้จาก PDF, reference list, หรือ official page | 0-5 |
| Directness of literature | แยก direct prior work, cross-domain support, foundational support, และ venue anchor ชัด | 0-5 |
| Objective alignment | objectives/RQs มาจากปัญหา และไม่มี objective ที่ลอยจาก gap | 0-5 |
| Objective-methodology verb alignment | คำกริยาใน objective สอดคล้องกับวิธีวิจัยและหลักฐานที่วิธีนั้นผลิตได้ เช่น quant/qual/design/R&D/mixed method | 0-5 |
| Alternatives and selection rationale | ระบุทางเลือกที่สมเหตุสมผลและอธิบายเหตุผลการเลือกวิธี ไม่ล็อกคำตอบไว้ตั้งแต่ problem statement | 0-5 |
| Method justification | วิธีแก้ปัญหา make sense และเทียบกับทางเลือก/วิธีนิยมใน field แล้ว | 0-5 |
| Baseline and alternatives | มี baseline หรือ alternative methods ที่ reviewer คาดหวัง | 0-5 |
| Results evidence | ผลหรือ expected results แสดงว่าปัญหาลดลง/ถูกแก้ตาม objective | 0-5 |
| Genuine failure test | งานมีเงื่อนไขที่ทำให้ตอบได้ว่าไม่สำเร็จ ไม่ตีความทุกผลเป็น success | 0-5 |
| Reproducible evidence | มี dataset/testbed, raw results, metric definitions, scripts, และ error cases เท่าที่จำเป็น | 0-5 |
| Traceability | problem-objective-method-result-contribution ต่อกันครบ | 0-5 |
| Output/outcome discipline | output แสดงว่าปัญหาถูกแก้ตาม objective และ outcome ถูกแยกจาก output พร้อมหลักฐานการวัดก่อนถูก claim | 0-5 |
| Academic/practical contribution discipline | แยก contribution ด้านวิชาการกับด้านปฏิบัติ/นโยบาย และไม่ claim outcome ปลายน้ำโดยไม่มีหลักฐาน | 0-5 |
| By-product and side-effect awareness | ระบุผลพลอยได้ ผลไม่ตั้งใจ ต้นทุน ภาระ หรือ trade-off ที่กระทบคุณค่าและขอบเขตของข้อสรุป | 0-5 |
| Problem survival | ปัญหายังมีอยู่จริง สำคัญ ยังไม่ถูกแก้พอแล้ว และ output ที่เสนอพิสูจน์ได้ว่าปัญหาลดลง | 0-5 |
| Mandatory gates | correctness, safety, security, ethics/legal หรือเกณฑ์ต้องผ่านอื่น ๆ ไม่ถูกกลบด้วยคะแนนเฉลี่ย/optimization metric | 0-5 |
| Measurement validity | construct, proxy/indicator, instrument/ground truth, procedure และ claim ต่อกันสมเหตุสมผล | 0-5 |
| Claim discipline | ไม่มี placeholder หรือ claim แรงเกินหลักฐาน เช่น significant/robust/verified/state-of-the-art | 0-5 |
| No-new-problem guardrail | solution ไม่สร้างหรือโยนภาระใหม่ที่ยอมรับไม่ได้ด้าน privacy, security, cost, fairness, maintainability หรือ stakeholder burden | 0-5 |
| Data feasibility | data หาได้จริง มี ground truth หรือ expert judgment และจัดการ privacy/permission ได้ | 0-5 |
| Ethics and IRB readiness | งานที่เกี่ยวข้องกับคน/ผู้ใช้/ข้อมูลส่วนบุคคลมี IRB, consent, de-identification, risk plan หรือ exemption ชัด | 0-5 |
| Legal and data compliance | ใช้ข้อมูล, dataset, scraping, license, copyright, privacy, ToS, NDA, หรือกฎ domain เฉพาะอย่างถูกต้องและระบุในเนื้อหาเมื่อจำเป็น | 0-5 |
| LLM responsibility | ถ้าใช้ LLM มีการตรวจแหล่งจริง เก็บ prompt/output และมี baseline/ขอบเขตการใช้ชัด | 0-5 |
| AI writing quality | ไม่มีร่องรอยใช้ AI แบบไร้คุณภาพ เช่น generic filler, claim ลอย, คำแปลแปลก, citation น่าสงสัย | 0-5 |
| Language hygiene | สะกดถูกพอสมควร ไม่มี typo มากเกินเหตุ และประโยคไม่ทำให้ความหมายวิชาการเสีย | 0-5 |
| Terminology and acronyms | ชื่อย่อ/คำย่อ/ศัพท์เทคนิคถูกนิยามก่อนใช้ ใช้สม่ำเสมอ และไม่ย่อแบบไม่เหมาะสม | 0-5 |
| Thai-English consistency | ใช้ไทย-อังกฤษปนกันเท่าที่จำเป็น ไม่สลับภาษาเกินเหตุ และคง technical term อย่างมีเหตุผล | 0-5 |
| Reader flow | ไม่อ้างไปยังสิ่งที่อยู่ด้านหลังโดยไม่มี context และลำดับการอธิบายอ่านตามได้ | 0-5 |
| Scope | ขอบเขตเป็น boundary ที่ตั้งใจและช่วยให้ thesis feasible | 0-5 |
| Limitations | ข้อจำกัดระบุ weakness/constraint ที่กระทบการตีความอย่างซื่อสัตย์ | 0-5 |
| Acknowledgement | acknowledgement เหมาะสม ไม่สร้างความกำกวมในเอกสารระยะยาว | 0-5 |
| Tables and figures | ตาราง/รูปอ่านได้ ชัด มี caption และถูกอ้างในตำแหน่งที่เหมาะสม | 0-5 |

## การแปลผล

- ค่าเฉลี่ยต่ำกว่า 2.0: ยังไม่ควรส่งให้อาจารย์ตรวจละเอียด ต้องแก้โครงสร้างก่อน
- 2.0-2.9: เป็น early draft มีทิศทางแต่ chain หลักยังขาด
- 3.0-3.7: ใช้เป็น thesis draft ได้ แต่ยังไม่น่าพร้อมสำหรับ venue จริง
- 3.8-4.4: ใกล้พร้อมสำหรับ defense/manuscript review ถ้าไม่มี blocking issue
- 4.5 ขึ้นไป: อาจพร้อมส่ง venue ที่ตั้งเป้า แต่ต้องตรวจ format, ethics, data, และ reference metadata อีกครั้ง

## Blocking Issues ที่ต้องแก้ก่อนเรื่องภาษา

- ระบุปัญหาไม่ชัด
- ปัญหาไม่รอด stress test เช่น ไม่มีหลักฐานว่ามีปัญหาจริง หรือมีวิธีเดิมที่แก้ได้พอแล้ว
- objective ไม่ได้แก้ปัญหาที่ตั้งไว้
- problem statement เป็นเพียงหัวข้อ คำถาม วิธีที่อยากใช้ หรือ deliverable ไม่ใช่สภาพปัญหาที่ตรวจได้
- ไม่แสดง prior attempts/unresolved need จึงไม่เห็นว่าทำไมงานนี้ยังจำเป็น
- ไม่มีทางเลือกหรือเหตุผลการเลือกวิธี ทำให้ method ดูเป็นความสะดวกมากกว่าการออกแบบวิจัย
- result ไม่ตอบ objective
- สับสน output กับ outcome เช่น claim ผลลัพธ์ปลายน้ำโดยไม่ได้วัด หรือถือ deliverable เป็นหลักฐานว่าปัญหาถูกแก้
- ไม่กล่าวถึง by-product, side effect, cost, burden หรือ trade-off ที่กระทบการตีความ
- งานไม่มีเงื่อนไขที่ทำให้ fail ได้ จึงพิสูจน์ success ไม่ได้
- ใช้ proxy/metric ที่วัดไม่ตรง construct แต่สรุป claim ใหญ่เกิน measurement
- mandatory gate ล้มเหลว แต่ถูกกลบด้วยค่าเฉลี่ยหรือ optimization metric
- solution สร้างปัญหาใหม่ที่รุนแรงกว่า เช่น privacy/security/fairness/stakeholder burden
- ไม่มี baseline หรือทางเลือกที่ reviewer ใน field คาดหวัง
- ไม่มี raw result/script/metric definition รองรับผลลัพธ์หลัก
- งานเกี่ยวข้องกับคนหรือข้อมูลส่วนบุคคลแต่ไม่กล่าวถึง IRB/ethics approval/exemption, consent, anonymization หรือ risk management
- ใช้ข้อมูลที่มี license, copyright, Terms of Service, confidentiality, NDA หรือข้อกฎหมายเฉพาะ แต่ไม่ระบุ permission/compliance
- literature review ไม่แสดง gap
- literature review ไม่พาไปสู่ research problem ที่ตรวจได้ เป็นเพียงการเล่า topic หรือวิธีที่อยากใช้
- author อธิบาย research gap แบบ assert เอง ไม่ได้ derive จาก prior work
- reference คุณภาพต่ำหรือไม่ตรง field
- cited key ไม่มีอยู่จริงใน BibTeX/reference list
- BibTeX มีรายการที่ trace กลับไปยัง PDF/reference list/official page ไม่ได้
- scholarly reference สำคัญไม่มี PDF ในมือ และไม่มี official source fallback ที่ระบุชัด
- BibTeX ขาด metadata หลักจนตรวจ source, DOI, venue, year หรือ abstract ไม่ได้
- citation หลักรองรับ claim ไม่ได้
- ใช้ reference ข้าม domain โดยไม่ qualify
- ใช้ LLM สร้าง claim/citation/venue metric โดยไม่ตรวจแหล่งจริง
- ใช้ AI ช่วยเขียนจนเนื้อหาดู generic, claim ลอย หรือคำแปลผิดบริบทวิชาการ
- สะกดผิดหรือ typo มากจนลดความน่าเชื่อถือของเอกสาร
- ใช้ชื่อย่อหรือคำย่อโดยไม่ define หรือใช้ไม่สม่ำเสมอ
- ปนภาษาไทย/อังกฤษมากเกินจำเป็นจนอ่านยากหรือทำให้ terminology ไม่ชัด
- อ้างถึงส่วน รูป ตาราง นิยาม หรือแนวคิดที่อยู่ด้านหลังโดยไม่มี context ให้ผู้อ่านเข้าใจก่อน
- ขอบเขตกับข้อจำกัดปนกันจนตีความ contribution ไม่ออก
- รูป/ตารางเป็นหลักฐานสำคัญแต่ดูไม่รู้เรื่อง
